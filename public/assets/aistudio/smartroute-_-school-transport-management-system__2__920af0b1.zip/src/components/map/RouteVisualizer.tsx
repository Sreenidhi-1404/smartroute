import React, { useState } from 'react';
import { Route, PickupPoint } from '../../types';
import { useData } from '../../context/DataContext';
import { MapPin, Navigation, Clock, Users, ArrowRight, Bus as BusIcon, Info } from 'lucide-react';
import { Badge } from '../common/Badge';

interface RouteVisualizerProps {
  route: Route;
  activeStopIndex?: number;
}

export const RouteVisualizer: React.FC<RouteVisualizerProps> = ({
  route,
  activeStopIndex = 1,
}) => {
  const { students, buses, drivers } = useData();
  const [selectedStop, setSelectedStop] = useState<PickupPoint | null>(
    route.pickupPoints[0] || null
  );
  const [viewMode, setViewMode] = useState<'schematic' | 'sequence'>('schematic');

  const bus = buses.find(b => b.id === route.assignedBusId);
  const driver = drivers.find(d => d.id === route.assignedDriverId);
  const routeStudents = students.filter(
    s => s.assignedRouteId === route.id && s.transportStatus === 'Active'
  );

  return (
    <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
      {/* Header bar */}
      <div className="px-5 py-4 border-b border-slate-100 flex flex-wrap items-center justify-between gap-3 bg-slate-50/70">
        <div>
          <div className="flex items-center gap-2">
            <span className="font-bold text-base text-slate-900">{route.name}</span>
            <Badge variant="info">{route.routeCode}</Badge>
            <Badge variant={route.status === 'Active' ? 'success' : 'neutral'}>
              {route.status}
            </Badge>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            {route.startLocation} <span className="text-slate-400">➔</span> {route.destination}
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center bg-white border border-slate-200 rounded-lg p-0.5 text-xs">
            <button
              onClick={() => setViewMode('schematic')}
              className={`px-3 py-1 rounded-md font-medium transition-all ${
                viewMode === 'schematic'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Interactive Map
            </button>
            <button
              onClick={() => setViewMode('sequence')}
              className={`px-3 py-1 rounded-md font-medium transition-all ${
                viewMode === 'sequence'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Stop Sequence
            </button>
          </div>

          <div className="hidden sm:flex items-center gap-4 text-xs text-slate-600 border-l border-slate-200 pl-4">
            <span className="flex items-center gap-1 font-medium">
              <Navigation className="w-3.5 h-3.5 text-blue-600" />
              {route.estimatedDistanceKm} km
            </span>
            <span className="flex items-center gap-1 font-medium">
              <Clock className="w-3.5 h-3.5 text-blue-600" />
              {route.estimatedDurationMin} min
            </span>
            <span className="flex items-center gap-1 font-medium">
              <Users className="w-3.5 h-3.5 text-blue-600" />
              {routeStudents.length} students
            </span>
          </div>
        </div>
      </div>

      {viewMode === 'schematic' ? (
        <div className="p-5">
          {/* Simulated Map Canvas */}
          <div className="relative w-full h-80 rounded-xl bg-slate-900/95 overflow-hidden border border-slate-800 p-6 flex flex-col justify-between shadow-inner">
            {/* Background Grid & Street Lines styling */}
            <div
              className="absolute inset-0 opacity-15 pointer-events-none"
              style={{
                backgroundImage:
                  'radial-gradient(#38bdf8 1px, transparent 1px), linear-gradient(to right, #1e293b 1px, transparent 1px), linear-gradient(to bottom, #1e293b 1px, transparent 1px)',
                backgroundSize: '24px 24px, 48px 48px, 48px 48px',
              }}
            />

            {/* Map Top Bar */}
            <div className="relative z-10 flex items-center justify-between text-xs text-slate-300">
              <div className="flex items-center gap-2 bg-slate-800/80 backdrop-blur-xs px-3 py-1.5 rounded-lg border border-slate-700">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span className="font-semibold text-slate-200">Scheduled Route Path</span>
                <span className="text-slate-400">({route.pickupPoints.length} stops)</span>
              </div>
              <div className="flex items-center gap-2 bg-slate-800/80 backdrop-blur-xs px-3 py-1.5 rounded-lg border border-slate-700">
                <BusIcon className="w-3.5 h-3.5 text-blue-400" />
                <span>
                  {bus ? bus.busNumber : 'Bus'} • {driver ? driver.name : 'Driver'}
                </span>
              </div>
            </div>

            {/* Interactive SVG Transit Path */}
            <div className="relative z-10 my-auto py-8">
              <div className="relative flex items-center justify-between">
                {/* Connecting Line */}
                <div className="absolute left-6 right-6 top-1/2 -translate-y-1/2 h-1.5 bg-slate-700 rounded-full">
                  <div
                    className="h-full bg-gradient-to-r from-blue-500 via-sky-400 to-emerald-400 rounded-full transition-all duration-700"
                    style={{
                      width: `${(activeStopIndex / (route.pickupPoints.length - 1)) * 100}%`,
                    }}
                  />
                </div>

                {/* Stop nodes */}
                {route.pickupPoints.map((stop, idx) => {
                  const isDestination = idx === route.pickupPoints.length - 1;
                  const isOrigin = idx === 0;
                  const isPassed = idx <= activeStopIndex;
                  const isSelected = selectedStop?.id === stop.id;
                  const stopStudents = routeStudents.filter(s => s.pickupPointId === stop.id);

                  return (
                    <div
                      key={stop.id}
                      onClick={() => setSelectedStop(stop)}
                      className="relative z-20 flex flex-col items-center group cursor-pointer"
                    >
                      {/* Node circle */}
                      <div
                        className={`w-9 h-9 rounded-full flex items-center justify-center font-bold text-xs transition-all shadow-md ${
                          isSelected
                            ? 'ring-4 ring-blue-400 scale-110'
                            : 'hover:scale-105'
                        } ${
                          isDestination
                            ? 'bg-emerald-500 text-white'
                            : isOrigin
                            ? 'bg-blue-600 text-white'
                            : isPassed
                            ? 'bg-sky-500 text-white'
                            : 'bg-slate-800 text-slate-300 border-2 border-slate-600'
                        }`}
                      >
                        {isDestination ? '🏫' : idx + 1}
                      </div>

                      {/* Moving bus badge over current progress stop */}
                      {idx === activeStopIndex && (
                        <div className="absolute -top-7 px-2 py-0.5 bg-blue-500 text-white text-[10px] font-bold rounded shadow-lg flex items-center gap-1 animate-bounce">
                          <BusIcon className="w-3 h-3" />
                          <span>Bus Location</span>
                        </div>
                      )}

                      {/* Name label */}
                      <div className="mt-2.5 text-center max-w-[100px]">
                        <span className="text-[11px] font-medium text-slate-200 line-clamp-1 group-hover:text-sky-300 transition-colors">
                          {stop.name}
                        </span>
                        <span className="text-[10px] text-slate-400 block mt-0.5">
                          {stop.morningTime}
                        </span>
                        {!isDestination && stopStudents.length > 0 && (
                          <span className="inline-block mt-1 text-[9px] px-1.5 py-0.2 bg-slate-800 text-sky-300 border border-slate-700 rounded-full">
                            {stopStudents.length} {stopStudents.length === 1 ? 'student' : 'students'}
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Simulated Map Bottom Notice */}
            <div className="relative z-10 flex items-center justify-between text-[11px] text-slate-400 border-t border-slate-800 pt-3">
              <span className="flex items-center gap-1">
                <Info className="w-3.5 h-3.5 text-slate-400" />
                Click any stop icon to inspect passenger boarding manifest and landmark notes.
              </span>
              <span>Speed limit regulated: 40 km/h</span>
            </div>
          </div>

          {/* Selected Stop Inspector Card */}
          {selectedStop && (
            <div className="mt-4 p-4 rounded-xl border border-slate-200 bg-blue-50/40 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-sm text-slate-900">
                    Stop #{selectedStop.order}: {selectedStop.name}
                  </span>
                  <Badge variant="outline">{selectedStop.address}</Badge>
                </div>
                <div className="flex flex-wrap items-center gap-4 text-xs text-slate-600">
                  <span>
                    <strong>Morning Pickup:</strong> {selectedStop.morningTime}
                  </span>
                  <span>
                    <strong>Afternoon Drop:</strong> {selectedStop.afternoonTime}
                  </span>
                  {selectedStop.landmark && (
                    <span className="text-slate-500 italic">
                      Landmark: {selectedStop.landmark}
                    </span>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <div className="text-right">
                  <div className="text-xs font-semibold text-slate-700">Allocated Students</div>
                  <div className="text-xs text-slate-500">
                    {routeStudents.filter(s => s.pickupPointId === selectedStop.id).length} boarding here
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      ) : (
        /* Detailed Sequence List */
        <div className="p-5">
          <div className="relative pl-6 space-y-6 before:absolute before:left-2.5 before:top-3 before:bottom-3 before:w-0.5 before:bg-slate-200">
            {route.pickupPoints.map((stop, i) => {
              const stopStudents = routeStudents.filter(s => s.pickupPointId === stop.id);
              const isSchool = i === route.pickupPoints.length - 1;

              return (
                <div key={stop.id} className="relative group">
                  {/* Pin */}
                  <div
                    className={`absolute -left-6 top-1 w-5 h-5 rounded-full border-2 border-white flex items-center justify-center text-[10px] font-bold shadow-xs ${
                      isSchool ? 'bg-emerald-600 text-white' : 'bg-blue-600 text-white'
                    }`}
                  >
                    {i + 1}
                  </div>

                  <div className="bg-slate-50 hover:bg-slate-100/80 transition-colors p-4 rounded-xl border border-slate-200/80">
                    <div className="flex flex-wrap items-start justify-between gap-2">
                      <div>
                        <h4 className="font-semibold text-sm text-slate-900 flex items-center gap-2">
                          {stop.name}
                          {isSchool && <Badge variant="success">Final Destination</Badge>}
                        </h4>
                        <p className="text-xs text-slate-500 mt-0.5 flex items-center gap-1">
                          <MapPin className="w-3.5 h-3.5 text-slate-400" />
                          {stop.address}
                        </p>
                      </div>

                      <div className="flex items-center gap-4 text-xs font-medium">
                        <span className="bg-white px-2.5 py-1 rounded-md border border-slate-200 text-slate-700">
                          AM: {stop.morningTime}
                        </span>
                        <span className="bg-white px-2.5 py-1 rounded-md border border-slate-200 text-slate-700">
                          PM: {stop.afternoonTime}
                        </span>
                      </div>
                    </div>

                    {stop.landmark && (
                      <p className="text-xs text-slate-500 mt-2 bg-white/60 p-2 rounded-lg border border-slate-100">
                        <strong>Landmark Reference:</strong> {stop.landmark}
                      </p>
                    )}

                    {!isSchool && stopStudents.length > 0 && (
                      <div className="mt-3 pt-2.5 border-t border-slate-200/60">
                        <span className="text-xs font-medium text-slate-600 block mb-1.5">
                          Assigned Students ({stopStudents.length}):
                        </span>
                        <div className="flex flex-wrap gap-1.5">
                          {stopStudents.map(s => (
                            <span
                              key={s.id}
                              className="text-xs px-2 py-0.5 bg-white border border-slate-200 rounded text-slate-700"
                            >
                              {s.name} (Gr {s.classGrade}{s.section})
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
