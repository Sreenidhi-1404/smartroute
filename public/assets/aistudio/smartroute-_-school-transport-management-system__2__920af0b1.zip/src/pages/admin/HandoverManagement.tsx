import React, { useState } from 'react';
import { useData } from '../../context/DataContext';
import { HandoverRecord, HandoverStatus, Student } from '../../types';
import {
  KeyRound,
  Search,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Phone,
  UserCheck,
  Shield,
  ShieldAlert,
  ArrowRight,
  Filter,
  Users,
} from 'lucide-react';
import { StatusBadge, Badge } from '../../components/common/Badge';
import { Modal } from '../../components/common/Modal';

export const HandoverManagement: React.FC = () => {
  const { handovers, students, routes, buses, drivers, verifyHandoverPin, updateHandoverStatus } = useData();

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  // Verify PIN modal
  const [selectedHandover, setSelectedHandover] = useState<HandoverRecord | null>(null);
  const [pinInput, setPinInput] = useState('');
  const [isVerifyModalOpen, setIsVerifyModalOpen] = useState(false);
  const [verifyMessage, setVerifyMessage] = useState<{ success: boolean; text: string } | null>(null);

  // Configure Guardians modal
  const [selectedStudentForGuardians, setSelectedStudentForGuardians] = useState<Student | null>(null);
  const [isGuardianModalOpen, setIsGuardianModalOpen] = useState(false);

  const filteredHandovers = handovers.filter(h => {
    const student = students.find(s => s.id === h.studentId);
    const matchesSearch =
      h.authorizedGuardianName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student?.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      h.guardianPhone.includes(searchTerm);
    const matchesStatus = statusFilter === 'all' || h.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const openVerifyModal = (h: HandoverRecord) => {
    setSelectedHandover(h);
    setPinInput('');
    setVerifyMessage(null);
    setIsVerifyModalOpen(true);
  };

  const handleVerifySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedHandover) return;

    const res = verifyHandoverPin(selectedHandover.id, pinInput, selectedHandover.driverId);
    setVerifyMessage({ success: res.success, text: res.message });
    if (res.success) {
      setTimeout(() => {
        setIsVerifyModalOpen(false);
      }, 1500);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
              FEATURE A • SAFETY PROTOCOL
            </span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Safe Student Handover Verification
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Parent one-time PIN verification system for safe drop-off at Coimbatore stops.
          </p>
        </div>
      </div>

      {/* Overview Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
          <span className="text-xs font-semibold text-slate-500 block">Total Handovers Today</span>
          <span className="text-2xl font-bold text-slate-900 mt-1 block">{handovers.length}</span>
          <span className="text-[11px] text-slate-400 mt-1 block">Scheduled afternoon runs</span>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
          <span className="text-xs font-semibold text-blue-600 block">Awaiting Verification</span>
          <span className="text-2xl font-bold text-blue-700 mt-1 block">
            {handovers.filter(h => h.status === 'Arrived at Drop-off' || h.status === 'Awaiting Guardian Verification').length}
          </span>
          <span className="text-[11px] text-blue-500 mt-1 block">Bus at designated stop</span>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
          <span className="text-xs font-semibold text-emerald-600 block">Safely Handed Over</span>
          <span className="text-2xl font-bold text-emerald-700 mt-1 block">
            {handovers.filter(h => h.status === 'Handed Over').length}
          </span>
          <span className="text-[11px] text-emerald-500 mt-1 block">PIN verified by driver</span>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
          <span className="text-xs font-semibold text-rose-600 block">Escalated Inquiries</span>
          <span className="text-2xl font-bold text-rose-700 mt-1 block">
            {handovers.filter(h => h.status === 'Escalated').length}
          </span>
          <span className="text-[11px] text-rose-500 mt-1 block">Incorrect PIN alerts</span>
        </div>
      </div>

      {/* Safety Protocol Banner */}
      <div className="p-4 bg-gradient-to-r from-blue-900 to-indigo-950 text-white rounded-xl shadow-xs space-y-2 text-xs">
        <div className="flex items-center gap-2">
          <Shield className="w-4 h-4 text-sky-400" />
          <h3 className="font-bold text-sm text-white">Handover Security Workflow</h3>
        </div>
        <p className="text-slate-300 leading-relaxed">
          When the school bus reaches the student's designated stop, the driver marks "Arrived at Stop".
          The guardian receives a verification request and provides their 4-digit PIN (visible in the Parent Portal).
          The driver enters the PIN to complete the handshake. Incorrect PINs escalate to the dispatch hotline.
        </p>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search student, guardian, phone..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <select
          value={statusFilter}
          onChange={e => setStatusFilter(e.target.value)}
          className="px-3 py-2 text-xs border border-slate-200 rounded-lg bg-white text-slate-700 self-end sm:self-auto"
        >
          <option value="all">All Handover Statuses</option>
          <option value="Awaiting Drop-off">Awaiting Drop-off</option>
          <option value="Arrived at Stop">Arrived at Stop</option>
          <option value="Handed Over">Handed Over</option>
          <option value="Escalated">Escalated</option>
        </select>
      </div>

      {/* Handovers Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
              <tr>
                <th className="px-4 py-3">Student Name</th>
                <th className="px-4 py-3">Handover Policy</th>
                <th className="px-4 py-3">Designated Stop</th>
                <th className="px-4 py-3">Authorized Guardian</th>
                <th className="px-4 py-3">Security OTP / Status</th>
                <th className="px-4 py-3">Driver</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3 text-right">Verification</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredHandovers.map(h => {
                const student = students.find(s => s.id === h.studentId);
                const route = routes.find(r => r.id === student?.assignedRouteId);
                const stop = route?.pickupPoints.find(p => p.id === h.pickupPointId);
                const driver = drivers.find(d => d.id === h.driverId);

                return (
                  <tr key={h.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="px-4 py-3">
                      <span className="font-bold text-slate-900 block">{student?.name}</span>
                      <span className="text-[11px] text-slate-400">
                        {student?.classGrade}-{student?.section} • {student?.studentIdNumber}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${
                          h.policy === 'Guardian Required'
                            ? 'bg-blue-100 text-blue-800'
                            : h.policy === 'Authorized Adult Required'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-indigo-100 text-indigo-800'
                        }`}
                      >
                        {h.policy}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span className="font-semibold text-slate-800 block">{stop?.name || 'Main Stop'}</span>
                      <span className="text-[11px] text-slate-400">{stop?.afternoonTime || '03:45 PM'}</span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="font-semibold text-slate-800">{h.authorizedGuardianName}</div>
                      <div className="text-[11px] text-slate-500 flex items-center gap-1">
                        <Phone className="w-3 h-3 text-slate-400" />
                        {h.guardianPhone}
                      </div>
                    </td>
                    <td className="px-4 py-3 font-mono font-bold text-slate-900">
                      {h.policy === 'Guardian Required' ? (
                        h.oneTimePin ? (
                          <span className="px-2 py-0.5 rounded bg-blue-50 text-blue-800 border border-blue-200">
                            OTP: {h.oneTimePin}
                          </span>
                        ) : (
                          <span className="text-[10px] text-slate-400 font-sans">Awaiting Drop Arrival</span>
                        )
                      ) : h.policy === 'Authorized Adult Required' ? (
                        <span className="text-[10px] text-amber-700 font-sans font-medium">In-Person ID Check</span>
                      ) : (
                        <span className="text-[10px] text-indigo-700 font-sans font-medium">Self Dismissal Pass</span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-slate-700">
                      <span className="font-medium">{driver?.name}</span>
                    </td>
                    <td className="px-4 py-3">
                      <StatusBadge status={h.status} />
                      {h.failedAttempts && h.failedAttempts > 0 && h.status !== 'Handed Over' ? (
                        <span className="text-[10px] text-rose-600 block font-semibold mt-0.5">
                          {h.failedAttempts}/5 attempts failed
                        </span>
                      ) : null}
                      {h.notes && (
                        <span className="text-[10px] text-slate-500 block truncate max-w-[150px] mt-0.5">
                          {h.notes}
                        </span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-right">
                      {h.status === 'Handed Over' ? (
                        <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                          ✓ Verified ({h.verifiedAt})
                        </span>
                      ) : h.status === 'Independently Dismissed' ? (
                        <span className="text-xs font-semibold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-200">
                          ✓ Dismissed ({h.dismissedAt})
                        </span>
                      ) : h.policy === 'Guardian Required' ? (
                        <button
                          onClick={() => openVerifyModal(h)}
                          className="px-3 py-1 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors"
                        >
                          Verify OTP
                        </button>
                      ) : (
                        <span className="text-xs font-medium text-slate-500">
                          Driver Verification
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* VERIFY PIN MODAL */}
      {selectedHandover && (
        <Modal
          isOpen={isVerifyModalOpen}
          onClose={() => setIsVerifyModalOpen(false)}
          title="Safe Student Handover: Enter Guardian PIN"
          subtitle={`Simulated PIN Handshake for ${students.find(s => s.id === selectedHandover.studentId)?.name}`}
          maxWidth="sm"
        >
          <form onSubmit={handleVerifySubmit} className="space-y-4 text-xs">
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
              <div>
                <strong>Student:</strong> {students.find(s => s.id === selectedHandover.studentId)?.name}
              </div>
              <div>
                <strong>Guardian at Stop:</strong> {selectedHandover.authorizedGuardianName}
              </div>
              <div>
                <strong>Registered Phone:</strong> {selectedHandover.guardianPhone}
              </div>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Enter 6-Digit Handover PIN Provided by Guardian *
              </label>
              <input
                type="text"
                maxLength={6}
                value={pinInput}
                onChange={e => setPinInput(e.target.value.replace(/\D/g, ''))}
                className="w-full px-3 py-2.5 text-center text-lg font-mono font-bold tracking-widest border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                placeholder="••••••"
                required
              />
              <span className="text-[11px] text-slate-500 block mt-1 text-center">
                (Admin Audit View: Active PIN is <strong>{selectedHandover.oneTimePin}</strong>)
              </span>
            </div>

            {verifyMessage && (
              <div
                className={`p-3 rounded-lg text-xs flex items-start gap-2 ${
                  verifyMessage.success
                    ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                    : 'bg-rose-50 text-rose-800 border border-rose-200'
                }`}
              >
                {verifyMessage.success ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                ) : (
                  <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                )}
                <span>{verifyMessage.text}</span>
              </div>
            )}

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setIsVerifyModalOpen(false)}
                className="px-3 py-1.5 font-medium text-slate-600 hover:bg-slate-100 rounded-lg"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs"
              >
                Confirm Handover
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
};
