import React, { useState, useMemo } from 'react';
import { useData } from '../../context/DataContext';
import {
  BarChart3,
  Download,
  Printer,
  Calendar,
  Filter,
  FileSpreadsheet,
  Bus as BusIcon,
  Users,
  UserCheck,
  ClipboardCheck,
  Navigation,
  MessageSquareWarning,
  Search,
} from 'lucide-react';
import { StatusBadge, Badge } from '../../components/common/Badge';
import { BarChart, DonutChart, ProgressBar } from '../../components/common/Charts';

type ReportType =
  | 'allocation'
  | 'utilization'
  | 'driver'
  | 'daily-attendance'
  | 'monthly-attendance'
  | 'trips'
  | 'route-students'
  | 'complaints';

export const ReportsAnalytics: React.FC = () => {
  const { students, buses, drivers, routes, allocations, attendance, trips, complaints, getBusOccupancy, settings } = useData();

  const [activeReport, setActiveReport] = useState<ReportType>('allocation');
  const [dateFilter, setDateFilter] = useState('2026-10-31');
  const [routeFilter, setRouteFilter] = useState('all');
  const [busFilter, setBusFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const reportTabs: { id: ReportType; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: 'allocation', label: '1. Student Allocation', icon: Users },
    { id: 'utilization', label: '2. Bus Utilization', icon: BusIcon },
    { id: 'driver', label: '3. Driver Assignment', icon: UserCheck },
    { id: 'daily-attendance', label: '4. Daily Attendance', icon: ClipboardCheck },
    { id: 'monthly-attendance', label: '5. Monthly Attendance', icon: Calendar },
    { id: 'trips', label: '6. Trip History', icon: Navigation },
    { id: 'route-students', label: '7. Route-wise Students', icon: BarChart3 },
    { id: 'complaints', label: '8. Complaints Report', icon: MessageSquareWarning },
  ];

  // Helper to trigger browser print
  const handlePrint = () => {
    window.print();
  };

  // CSV Generator for active report
  const handleExportCSV = () => {
    let headers: string[] = [];
    let rows: string[][] = [];
    let filename = `smartroute_${activeReport}_${dateFilter}.csv`;

    if (activeReport === 'allocation') {
      headers = ['Student ID', 'Student Name', 'Grade', 'Route Code', 'Route Name', 'Bus Number', 'Pickup Stop', 'Status'];
      rows = allocations.map(a => {
        const student = students.find(s => s.id === a.studentId);
        const route = routes.find(r => r.id === a.routeId);
        const bus = buses.find(b => b.id === a.busId);
        const stop = route?.pickupPoints.find(p => p.id === a.pickupPointId);
        return [
          student?.studentIdNumber || a.studentId,
          `"${student?.name || ''}"`,
          student ? `Grade ${student.classGrade}${student.section}` : '',
          route?.routeCode || '',
          `"${route?.name || ''}"`,
          bus?.busNumber || '',
          `"${stop?.name || ''}"`,
          a.status,
        ];
      });
    } else if (activeReport === 'utilization') {
      headers = ['Bus Number', 'Plate Registration', 'Model', 'Capacity', 'Occupancy', 'Available Seats', 'Utilization %', 'Status'];
      rows = buses.map(b => {
        const occ = getBusOccupancy(b.id);
        return [
          b.busNumber,
          b.registrationNumber,
          `"${b.model}"`,
          String(occ.capacity),
          String(occ.occupied),
          String(occ.available),
          `${occ.percentage}%`,
          b.status,
        ];
      });
    } else if (activeReport === 'driver') {
      headers = ['Driver Code', 'Driver Name', 'Phone', 'License No', 'License Expiry', 'Assigned Bus', 'Status', 'Rating'];
      rows = drivers.map(d => {
        const bus = buses.find(b => b.assignedDriverId === d.id);
        return [
          d.driverCode,
          `"${d.name}"`,
          d.phone,
          d.licenseNumber,
          d.licenseExpiryDate,
          bus?.busNumber || 'None',
          d.status,
          String(d.rating),
        ];
      });
    } else if (activeReport === 'daily-attendance' || activeReport === 'monthly-attendance') {
      headers = ['Date', 'Session', 'Student ID', 'Student Name', 'Route Code', 'Bus', 'Status', 'Marked Time'];
      rows = attendance.map(att => {
        const student = students.find(s => s.id === att.studentId);
        const bus = buses.find(b => b.id === att.busId);
        const route = routes.find(r => r.id === att.routeId);
        return [
          att.date,
          att.session,
          student?.studentIdNumber || att.studentId,
          `"${student?.name || ''}"`,
          route?.routeCode || '',
          bus?.busNumber || '',
          att.status,
          att.markedTime || 'N/A',
        ];
      });
    } else if (activeReport === 'trips') {
      headers = ['Trip Code', 'Date', 'Session', 'Route', 'Bus', 'Driver', 'Scheduled Time', 'Status', 'Delay Reason'];
      rows = trips.map(t => {
        const bus = buses.find(b => b.id === t.busId);
        const driver = drivers.find(d => d.id === t.driverId);
        const route = routes.find(r => r.id === t.routeId);
        return [
          t.tripCode,
          t.date,
          t.session,
          `"${route?.name || ''}"`,
          bus?.busNumber || '',
          `"${driver?.name || ''}"`,
          `${t.scheduledStartTime} - ${t.expectedArrivalTime}`,
          t.status,
          `"${t.delayReason || ''}"`,
        ];
      });
    } else if (activeReport === 'route-students') {
      headers = ['Route Code', 'Route Name', 'Distance (km)', 'Duration (min)', 'Assigned Students', 'Capacity'];
      rows = routes.map(r => {
        const count = students.filter(s => s.assignedRouteId === r.id && s.transportStatus === 'Active').length;
        return [r.routeCode, `"${r.name}"`, String(r.estimatedDistanceKm), String(r.estimatedDurationMin), String(count), '40'];
      });
    } else if (activeReport === 'complaints') {
      headers = ['Complaint Code', 'Date', 'Category', 'Priority', 'Subject', 'Submitted By', 'Status', 'Resolution'];
      rows = complaints.map(c => [
        c.complaintCode,
        c.submissionDate.split('T')[0],
        c.category,
        c.priority,
        `"${c.subject}"`,
        `"${c.submittedByName}"`,
        c.status,
        `"${c.adminResponse || ''}"`,
      ]);
    }

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Reports & Fleet Analytics
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Audit-grade operational intelligence, bus capacity reports, and printable dispatch rosters.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handlePrint}
            className="px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg shadow-xs flex items-center gap-1.5 transition-colors"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Report</span>
          </button>
          <button
            onClick={handleExportCSV}
            className="px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs flex items-center gap-1.5 transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* 8 Report Tabs Bar */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-slate-200 scrollbar-none">
        {reportTabs.map(tab => {
          const Icon = tab.icon;
          const isActive = activeReport === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveReport(tab.id)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold whitespace-nowrap transition-all border ${
                isActive
                  ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                  : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Report Filter Bar */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs flex flex-wrap gap-3 items-center justify-between">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1.5 text-xs text-slate-600">
            <Calendar className="w-4 h-4 text-slate-400" />
            <input
              type="date"
              value={dateFilter}
              onChange={e => setDateFilter(e.target.value)}
              className="px-3 py-1.5 border border-slate-300 rounded-lg text-xs"
            />
          </div>

          <select
            value={routeFilter}
            onChange={e => setRouteFilter(e.target.value)}
            className="px-3 py-1.5 text-xs border border-slate-300 rounded-lg bg-white text-slate-700"
          >
            <option value="all">All Corridors</option>
            {routes.map(r => (
              <option key={r.id} value={r.id}>
                {r.routeCode} ({r.name})
              </option>
            ))}
          </select>

          <select
            value={busFilter}
            onChange={e => setBusFilter(e.target.value)}
            className="px-3 py-1.5 text-xs border border-slate-300 rounded-lg bg-white text-slate-700"
          >
            <option value="all">All Fleet Buses</option>
            {buses.map(b => (
              <option key={b.id} value={b.id}>
                {b.busNumber} ({b.registrationNumber})
              </option>
            ))}
          </select>
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search report entries..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </div>

      {/* Printable Report Document Card */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 space-y-6 print:border-none print:shadow-none print:p-0">
        {/* Document Header for Official School Printing */}
        <div className="border-b border-slate-200 pb-4 flex items-start justify-between">
          <div>
            <h2 className="text-lg font-bold text-slate-900">{settings.schoolName}</h2>
            <p className="text-xs text-slate-500">
              Department of Pupil Transportation • Academic Year {settings.academicYear}
            </p>
            <p className="text-xs text-slate-400 mt-0.5">
              Report Generated: {new Date().toLocaleDateString()} • Dispatch Period: {dateFilter}
            </p>
          </div>
          <div className="text-right">
            <span className="text-xs font-mono font-bold text-blue-700 uppercase bg-blue-50 px-2 py-1 rounded border border-blue-200">
              {activeReport.replace('-', ' ').toUpperCase()} REPORT
            </span>
          </div>
        </div>

        {/* Dynamic Content based on active report */}
        {activeReport === 'allocation' && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs">
                <span className="text-slate-500 block">Total Active Allocations</span>
                <span className="font-bold text-base text-slate-900">
                  {allocations.filter(a => a.status === 'Active').length}
                </span>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs">
                <span className="text-slate-500 block">Unassigned Enrollees</span>
                <span className="font-bold text-base text-amber-600">
                  {students.filter(s => s.transportStatus !== 'Active').length}
                </span>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs">
                <span className="text-slate-500 block">Fleet Capacity</span>
                <span className="font-bold text-base text-slate-900">200 Seats</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs">
                <span className="text-slate-500 block">Allocation Rate</span>
                <span className="font-bold text-base text-emerald-600">96%</span>
              </div>
            </div>

            <div className="border border-slate-200 rounded-lg overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 font-semibold text-slate-700">
                  <tr>
                    <th className="px-3 py-2.5">Student ID</th>
                    <th className="px-3 py-2.5">Full Name</th>
                    <th className="px-3 py-2.5">Grade</th>
                    <th className="px-3 py-2.5">Route</th>
                    <th className="px-3 py-2.5">Bus</th>
                    <th className="px-3 py-2.5">Pickup Point</th>
                    <th className="px-3 py-2.5">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {allocations.slice(0, 15).map(alloc => {
                    const student = students.find(s => s.id === alloc.studentId);
                    const route = routes.find(r => r.id === alloc.routeId);
                    const bus = buses.find(b => b.id === alloc.busId);
                    const stop = route?.pickupPoints.find(p => p.id === alloc.pickupPointId);

                    return (
                      <tr key={alloc.id}>
                        <td className="px-3 py-2 font-mono">{student?.studentIdNumber}</td>
                        <td className="px-3 py-2 font-semibold text-slate-900">{student?.name}</td>
                        <td className="px-3 py-2">Grade {student?.classGrade}-{student?.section}</td>
                        <td className="px-3 py-2">{route?.routeCode}</td>
                        <td className="px-3 py-2 font-medium">{bus?.busNumber}</td>
                        <td className="px-3 py-2 text-slate-600">{stop?.name}</td>
                        <td className="px-3 py-2"><StatusBadge status={alloc.status} /></td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeReport === 'utilization' && (
          <div className="space-y-4">
            <div className="border border-slate-200 rounded-lg overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 font-semibold text-slate-700">
                  <tr>
                    <th className="px-3 py-2.5">Bus Number</th>
                    <th className="px-3 py-2.5">Registration</th>
                    <th className="px-3 py-2.5">Model</th>
                    <th className="px-3 py-2.5">Capacity</th>
                    <th className="px-3 py-2.5">Occupied</th>
                    <th className="px-3 py-2.5">Available</th>
                    <th className="px-3 py-2.5">Progress</th>
                    <th className="px-3 py-2.5">Condition</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {buses.map(bus => {
                    const occ = getBusOccupancy(bus.id);
                    return (
                      <tr key={bus.id}>
                        <td className="px-3 py-2.5 font-bold text-slate-900">{bus.busNumber}</td>
                        <td className="px-3 py-2.5 font-mono text-slate-600">{bus.registrationNumber}</td>
                        <td className="px-3 py-2.5">{bus.model}</td>
                        <td className="px-3 py-2.5 font-medium">{occ.capacity}</td>
                        <td className="px-3 py-2.5 font-semibold text-blue-600">{occ.occupied}</td>
                        <td className="px-3 py-2.5 font-semibold text-emerald-600">{occ.available}</td>
                        <td className="px-3 py-2.5 w-36">
                          <ProgressBar value={occ.percentage} size="sm" showPercentage={true} />
                        </td>
                        <td className="px-3 py-2.5">
                          <Badge variant={bus.maintenanceStatus === 'Good' ? 'success' : 'warning'}>
                            {bus.maintenanceStatus}
                          </Badge>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeReport === 'driver' && (
          <div className="border border-slate-200 rounded-lg overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 font-semibold text-slate-700">
                <tr>
                  <th className="px-3 py-2.5">Driver Code</th>
                  <th className="px-3 py-2.5">Operator Name</th>
                  <th className="px-3 py-2.5">Phone</th>
                  <th className="px-3 py-2.5">License Number</th>
                  <th className="px-3 py-2.5">Expiry Date</th>
                  <th className="px-3 py-2.5">Assigned Bus</th>
                  <th className="px-3 py-2.5">Safety Rating</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {drivers.map(driver => {
                  const bus = buses.find(b => b.assignedDriverId === driver.id);
                  return (
                    <tr key={driver.id}>
                      <td className="px-3 py-2 font-mono font-medium">{driver.driverCode}</td>
                      <td className="px-3 py-2 font-semibold text-slate-900">{driver.name}</td>
                      <td className="px-3 py-2 text-slate-600">{driver.phone}</td>
                      <td className="px-3 py-2 font-mono">{driver.licenseNumber}</td>
                      <td className="px-3 py-2">{driver.licenseExpiryDate}</td>
                      <td className="px-3 py-2 font-bold text-slate-800">{bus?.busNumber || 'None'}</td>
                      <td className="px-3 py-2 font-semibold text-amber-600">{driver.rating} ★</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {(activeReport === 'daily-attendance' || activeReport === 'monthly-attendance') && (
          <div className="border border-slate-200 rounded-lg overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 font-semibold text-slate-700">
                <tr>
                  <th className="px-3 py-2.5">Log Date</th>
                  <th className="px-3 py-2.5">Session</th>
                  <th className="px-3 py-2.5">Student ID</th>
                  <th className="px-3 py-2.5">Passenger Name</th>
                  <th className="px-3 py-2.5">Route</th>
                  <th className="px-3 py-2.5">Bus</th>
                  <th className="px-3 py-2.5">Status</th>
                  <th className="px-3 py-2.5">Boarding Time</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {attendance.slice(0, 15).map(att => {
                  const student = students.find(s => s.id === att.studentId);
                  const bus = buses.find(b => b.id === att.busId);
                  const route = routes.find(r => r.id === att.routeId);
                  return (
                    <tr key={att.id}>
                      <td className="px-3 py-2 font-mono">{att.date}</td>
                      <td className="px-3 py-2">{att.session}</td>
                      <td className="px-3 py-2 font-mono">{student?.studentIdNumber}</td>
                      <td className="px-3 py-2 font-semibold text-slate-900">{student?.name}</td>
                      <td className="px-3 py-2">{route?.routeCode}</td>
                      <td className="px-3 py-2">{bus?.busNumber}</td>
                      <td className="px-3 py-2"><StatusBadge status={att.status} /></td>
                      <td className="px-3 py-2 text-slate-600 font-mono">{att.markedTime || 'Absent'}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {activeReport === 'trips' && (
          <div className="border border-slate-200 rounded-lg overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 font-semibold text-slate-700">
                <tr>
                  <th className="px-3 py-2.5">Trip Code</th>
                  <th className="px-3 py-2.5">Date</th>
                  <th className="px-3 py-2.5">Session</th>
                  <th className="px-3 py-2.5">Route</th>
                  <th className="px-3 py-2.5">Bus & Operator</th>
                  <th className="px-3 py-2.5">Timetable</th>
                  <th className="px-3 py-2.5">Status</th>
                  <th className="px-3 py-2.5">Incident / Delay Notes</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {trips.map(trip => {
                  const bus = buses.find(b => b.id === trip.busId);
                  const driver = drivers.find(d => d.id === trip.driverId);
                  const route = routes.find(r => r.id === trip.routeId);
                  return (
                    <tr key={trip.id}>
                      <td className="px-3 py-2 font-mono font-medium">{trip.tripCode}</td>
                      <td className="px-3 py-2">{trip.date}</td>
                      <td className="px-3 py-2">{trip.session}</td>
                      <td className="px-3 py-2">{route?.name}</td>
                      <td className="px-3 py-2">{bus?.busNumber} ({driver?.name})</td>
                      <td className="px-3 py-2 text-slate-600">{trip.scheduledStartTime} - {trip.expectedArrivalTime}</td>
                      <td className="px-3 py-2"><StatusBadge status={trip.status} /></td>
                      <td className="px-3 py-2 text-slate-500 italic">{trip.delayReason || 'On schedule'}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {activeReport === 'route-students' && (
          <div className="border border-slate-200 rounded-lg overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 font-semibold text-slate-700">
                <tr>
                  <th className="px-3 py-2.5">Route Code</th>
                  <th className="px-3 py-2.5">Corridor Name</th>
                  <th className="px-3 py-2.5">Distance</th>
                  <th className="px-3 py-2.5">Duration</th>
                  <th className="px-3 py-2.5">Intermediate Stops</th>
                  <th className="px-3 py-2.5">Assigned Students</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {routes.map(route => {
                  const assigned = students.filter(s => s.assignedRouteId === route.id && s.transportStatus === 'Active');
                  return (
                    <tr key={route.id}>
                      <td className="px-3 py-2 font-mono font-bold text-slate-900">{route.routeCode}</td>
                      <td className="px-3 py-2 font-semibold text-slate-800">{route.name}</td>
                      <td className="px-3 py-2">{route.estimatedDistanceKm} km</td>
                      <td className="px-3 py-2">{route.estimatedDurationMin} min</td>
                      <td className="px-3 py-2">{route.pickupPoints.length} stops</td>
                      <td className="px-3 py-2 font-bold text-blue-600">{assigned.length} students</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {activeReport === 'complaints' && (
          <div className="border border-slate-200 rounded-lg overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 font-semibold text-slate-700">
                <tr>
                  <th className="px-3 py-2.5">Case Code</th>
                  <th className="px-3 py-2.5">Category</th>
                  <th className="px-3 py-2.5">Priority</th>
                  <th className="px-3 py-2.5">Subject</th>
                  <th className="px-3 py-2.5">Submitted By</th>
                  <th className="px-3 py-2.5">Status</th>
                  <th className="px-3 py-2.5">Administrative Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {complaints.map(c => (
                  <tr key={c.id}>
                    <td className="px-3 py-2 font-mono font-medium">{c.complaintCode}</td>
                    <td className="px-3 py-2"><Badge variant="outline">{c.category}</Badge></td>
                    <td className="px-3 py-2 font-semibold">{c.priority}</td>
                    <td className="px-3 py-2 font-medium text-slate-900">{c.subject}</td>
                    <td className="px-3 py-2 text-slate-600">{c.submittedByName}</td>
                    <td className="px-3 py-2"><StatusBadge status={c.status} /></td>
                    <td className="px-3 py-2 text-slate-600 max-w-xs truncate">{c.adminResponse || 'Pending'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Official Signature Footer for Print */}
        <div className="hidden print:flex items-center justify-between pt-12 border-t border-slate-300 text-xs">
          <div>
            <div className="w-48 border-b border-slate-400 mb-1" />
            <span>Transport Coordinator Signature</span>
          </div>
          <div className="text-right">
            <div className="w-48 border-b border-slate-400 mb-1 ml-auto" />
            <span>Head of School / Director Approval</span>
          </div>
        </div>
      </div>
    </div>
  );
};
